#! /bin/bash
# find the most recently installed nx client
# try in-client updates first
NX_LOCAL_PATH="$HOME/.local/share/Network Optix/client/default"
CURRENTVER=$(dir --width=20 -r "$NX_LOCAL_PATH" | head -1)
if [ -f "$NX_LOCAL_PATH/$CURRENTVER/bin/client-bin" ]; then
    "$NX_LOCAL_PATH/$CURRENTVER/bin/client-bin" --no-hidpi --show-full-info $@ &
else
# fallback to full-installed version
    NX_LOCAL_PATH="/opt/networkoptix/client/"
    CURRENTVER=$(dir --width=20 -r "$NX_LOCAL_PATH" | head -1)
    "$NX_LOCAL_PATH/$CURRENTVER/bin/client-bin" --no-hidpi --show-full-info $@ &
fi
