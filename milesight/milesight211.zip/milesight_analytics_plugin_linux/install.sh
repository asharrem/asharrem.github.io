read -p "Network Optix Media Server will stop, do you need to continue? [Continue by pressing Y key,stop install by pressing other keys.]" input
        case $input in
                [yY])

                ;;
		*)
			exit 0  
		;;	
        esac

if [ -d "/opt/networkoptix/mediaserver/bin/plugins/milesight_analytics_plugin" ];then
	sudo rm -rf /opt/networkoptix/mediaserver/bin/plugins/milesight_analytics_plugin
fi

if [ -f "/opt/networkoptix/mediaserver/bin/plugins/libmilesight_analytics_plugin.so" ];then
	read -p "Detected the original plugin of version 1.0.1.Coexistence may consume performance and storage space.Do you want to delete it? [Delete by pressing Y key, do not delete by pressing other keys.]" input
	case $input in
		[yY])
			sudo mv /opt/networkoptix/mediaserver/bin/plugins/libmilesight_analytics_plugin.so /opt/networkoptix/mediaserver/bin/plugins_optional/
			echo We have moved the original plugin file to "/opt/networkoptix/mediaserver/bin/plugins_optional". If you no longer need it, you can delete it.
		;;
	esac	
fi

if [ -d "./milesight_analytics_plugin" ];then
	sudo mkdir -p /opt/networkoptix/mediaserver/bin/plugins/milesight_analytics_plugin
	sudo cp ./milesight_analytics_plugin/* /opt/networkoptix/mediaserver/bin/plugins/milesight_analytics_plugin/
fi

sudo systemctl restart networkoptix-mediaserver
