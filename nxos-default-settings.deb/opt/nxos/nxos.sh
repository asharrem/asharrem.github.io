#! /bin/bash

# Closing the Nx Client will logout

# openbox is my window manager
openbox-session &

# find the most recently installed nx client
CURRENTVER=$(ls -t /opt/networkoptix/client/ | head -1)

# always run the latest client with the --no-hdmi option
# needed to fix scaling issue with 4k TV's
/opt/networkoptix/client/"$CURRENTVER"/bin/client-bin --no-hidpi --show-full-info $@
openbox --exit
