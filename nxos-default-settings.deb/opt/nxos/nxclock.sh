#! /bin/bash
openbox &
xdaliclock -fullscreen -noseconds -nocycle -24 -title "NxOS" -builtin3
openbox --exit
