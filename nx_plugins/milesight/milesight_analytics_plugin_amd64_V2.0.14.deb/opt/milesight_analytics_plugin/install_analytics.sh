#!/bin/bash

# ==================== global cfg ====================
set -e

SERVICES=(
    "networkoptix-mediaserver:/opt/networkoptix/mediaserver/bin"
    "networkoptix-metavms-mediaserver:/opt/networkoptix-metavms/mediaserver/bin"
    "digitalwatchdog-mediaserver:/opt/digitalwatchdog/mediaserver/bin"
    "hanwha-mediaserver:/opt/hanwha/mediaserver/bin"
    "auroratec-mediaserver:/opt/auroratec/mediaserver/bin"
    "eyeq-mediaserver:/opt/eyeq/mediaserver/bin"
    "actioncs-mediaserver:/opt/actioncs/mediaserver/bin"
    "sharpvue-mediaserver:/opt/sharpvue/mediaserver/bin"
    "piko-mediaserver:/opt/piko/mediaserver/bin"
)

PLUGIN_ANALYTICS_SRC="./milesight_analytics_plugin"

# NX keeps a separate plugin backup under /opt/networkoptix/plugins, independent of each
# mediaserver's bin/plugins. Keep it in sync so an NX-side restore can't bring back a stale .so.
NX_BACKUP_PLUGIN_DIR="/opt/networkoptix/plugins/milesight_analytics_plugin"

install_plugin() {
    local SVC_NAME="$1"
    local BASE_PATH="$2"

    if [ ! -d "$BASE_PATH" ]; then
        #echo "Directory $BASE_PATH not found, skipping $SVC_NAME installation."
        return 0
    fi

    echo ""
    echo "=============================================="
    echo "Installing plugin for $SVC_NAME at $BASE_PATH ..."

    local PLUGIN_BASE="$BASE_PATH/plugins"
    local PLUGIN_OPTIONAL="$BASE_PATH/plugins_optional"
    local ANALYTICS_PLUGIN_DIR="$PLUGIN_BASE/milesight_analytics_plugin"
    local LEGACY_PLUGIN_FILE="$PLUGIN_BASE/libmilesight_analytics_plugin.so"

    # Migrate the legacy 1.0.1 single-file plugin out of the way (ask user).
    if [ -f "$LEGACY_PLUGIN_FILE" ]; then
        read -p "Detected the original plugin of version 1.0.1.Coexistence may consume performance and storage space.Do you want to delete it? [Delete by pressing Y key, do not delete by pressing other keys.]" input
        case "$input" in
            [yY])
                sudo mkdir -p "$PLUGIN_OPTIONAL"
                sudo mv "$LEGACY_PLUGIN_FILE" "$PLUGIN_OPTIONAL/"
                echo "We have moved the original plugin file to $PLUGIN_OPTIONAL. If you no longer need it, you can delete it."
                ;;
        esac
    fi

    if [ -d "$ANALYTICS_PLUGIN_DIR" ]; then
        echo "Removing old analytics plugin directory..."
        sudo rm -rf "$ANALYTICS_PLUGIN_DIR"
    fi

    if [ -d "$PLUGIN_ANALYTICS_SRC" ]; then
        echo "Copying analytics plugin files..."
        sudo mkdir -p "$ANALYTICS_PLUGIN_DIR"
        sudo cp "$PLUGIN_ANALYTICS_SRC"/* "$ANALYTICS_PLUGIN_DIR/"
        # 777 so the upgrade script (running as the mediaserver user, not root) can rename
        # the in-use .so files during a self-upgrade.
        sudo chmod -R 777 "$ANALYTICS_PLUGIN_DIR"

        # Sync into the NX plugin backup dir too, but only if it already exists (don't create it).
        if [ -d "$NX_BACKUP_PLUGIN_DIR" ]; then
            echo "Updating NX plugin backup at $NX_BACKUP_PLUGIN_DIR ..."
            sudo rm -rf "$NX_BACKUP_PLUGIN_DIR"/*
            sudo cp "$PLUGIN_ANALYTICS_SRC"/* "$NX_BACKUP_PLUGIN_DIR/"
            sudo chmod -R 777 "$NX_BACKUP_PLUGIN_DIR"
        fi
    else
        echo "Warning: $PLUGIN_ANALYTICS_SRC not found, skipping analytics plugin."
    fi

    # Upgrade workspace (msplugin_Upgrade) -- holds upgradeLog.json + upgradePlugin.sh at runtime.
    local UPGRADE_DIR="$BASE_PATH/msplugin_Upgrade_Milesight"
    sudo mkdir -p "$UPGRADE_DIR"
    if [ -f "./upgradePlugin.sh" ]; then
        sudo cp "./upgradePlugin.sh" "$UPGRADE_DIR/"
        sudo chmod 755 "$UPGRADE_DIR/upgradePlugin.sh"
    else
        echo "Warning: upgradePlugin.sh not found, plugin self-upgrade will not be available."
    fi
    sudo chmod 777 "$UPGRADE_DIR"

    echo "restarting $SVC_NAME..."
    sudo systemctl restart "$SVC_NAME" || true

    echo "Installation for $SVC_NAME completed."
}

# ==================== main process ====================
echo "=============================================="
echo "Milesight Analytics Plugin Installer for Multiple VMS"
echo "=============================================="

if [ ! -d "$PLUGIN_ANALYTICS_SRC" ]; then
    echo "Error: Plugin source directory not found in current path."
    echo "Please ensure 'milesight_analytics_plugin' folder exists."
    exit 1
fi

# Iterate through all services and install
for entry in "${SERVICES[@]}"; do
    IFS=':' read -r svc_name base_path <<< "$entry"
    install_plugin "$svc_name" "$base_path"
done

echo ""
echo "=============================================="
echo "All plugins processed."
echo "=============================================="
