#!/bin/sh
#
# Plugin self-upgrade entry point (oem_0 / milesight variant).
#   $1 = absolute path to the downloaded plugin package (msplugin_Upgrade/<file>).
#
# Replace-only: this script does NOT stop or start the mediaserver service. The mediaserver
# stays alive while we replace the plugin files on disk. Once we write status=complish, the
# C++ side terminates the mediaserver itself; SCM/systemd respawns it, and the new mediaserver
# loads the new plugin from disk.
#
# Existing files are renamed with a timestamped .old suffix before the new files are dropped
# in. This sidesteps "file is in use" failures: the loaded library keeps its inode/handle even
# after the directory entry is renamed.

PKG="$1"
# $2 = absolute plugin install dir, passed explicitly by the C++ launcher. The upgrade
# workspace and the installed plugin may live on different mount points (embedded: workspace
# on /mnt/nand3, plugin on /mnt/nand5), so we must NOT infer the install dir from $0. Empty
# when launched by an older mediaserver -- we fall back to the SCRIPT_DIR/.. guess below.
PLUGIN_DIR_ARG="$2"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_FILE="$SCRIPT_DIR/upgradeLog.json"
LOG_DIR="$SCRIPT_DIR/upgradeLog"
RUN_LOG="$LOG_DIR/upgrade.run.log"
EXTRACT_DIR="$SCRIPT_DIR/extracted"
BACKUP_ROOT="$SCRIPT_DIR/pluginBackUp"
PLUGIN_NAME="milesight_analytics_plugin"
TS="$(date +%Y%m%d-%H%M%S)"

# Tee the entire run to RUN_LOG so we can see exactly where it died if the script is killed
# externally. The __TEED__ guard ($3) prevents recursion. RUN_LOG is truncated each run so it
# only contains the latest invocation. Re-exec preserves $1 (pkg) and $2 (plugin dir).
if [ "$3" != "__TEED__" ]; then
    mkdir -p "$LOG_DIR"
    : > "$RUN_LOG"
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] script start, pkg=$1 pluginDir=$2" >> "$RUN_LOG"
    exec sh "$0" "$1" "$2" __TEED__ >> "$RUN_LOG" 2>&1
fi

# msplugin_Upgrade lives inside <MediaServer>/, so the parent of SCRIPT_DIR IS our target
# install. We don't iterate every known OEM path -- we only touch ours.
BASE_PATH="$(cd "$SCRIPT_DIR/.." && pwd)"

# Only the terminal status (complish/error) is written from here. The mediaserver writes the
# initial "upgrading" entry with our pid, and the C++ side reaps it if this process disappears.
write_log() {
    local status="$1"
    local err="$2"
    cat > "$LOG_FILE" <<EOF
{
  "status": "$status",
  "errorStr": "$err",
  "pid": 0,
  "updateTime": "$(date +'%Y-%m-%d %H:%M:%S')"
}
EOF
}

fail() {
    echo "[ERROR] $1"
    write_log "error" "$1"
    exit 1
}

echo "=============================================="
echo "Milesight Plugin Self-Upgrade (replace-only)"
echo "=============================================="
echo "Package : $PKG"
echo "Script  : $SCRIPT_DIR"
echo "=============================================="

# ---- 0. Validate package ---------------------------------------------------
if [ -z "$PKG" ] || [ ! -f "$PKG" ]; then
    fail "Package not found: $PKG"
fi

# ---- 1. Extract the package once into a workspace -------------------------
rm -rf "$EXTRACT_DIR"
mkdir -p "$EXTRACT_DIR"

extracted=0
case "$PKG" in
    *.zip)
        if command -v unzip >/dev/null; then
            unzip -o "$PKG" -d "$EXTRACT_DIR" && extracted=1
        else
            echo "[ERROR] 'unzip' not found in PATH"
        fi
        ;;
    *.tar.gz|*.tgz)
        tar -xzvf "$PKG" -C "$EXTRACT_DIR" && extracted=1
        ;;
    *.tar)
        tar -xvf "$PKG" -C "$EXTRACT_DIR" && extracted=1
        ;;
    *.7z)
        if command -v 7z >/dev/null; then
            7z x -y -o"$EXTRACT_DIR" "$PKG" && extracted=1
        else
            echo "[ERROR] '7z' not found in PATH"
        fi
        ;;
esac
[ "$extracted" -eq 1 ] || fail "Failed to extract package: $PKG"

# Locate the plugin source folder inside the extracted tree (could be at any depth).
SRC_DIR="$(find "$EXTRACT_DIR" -type d -name "$PLUGIN_NAME" -print -quit)"
[ -n "$SRC_DIR" ] || fail "Plugin folder '$PLUGIN_NAME' not found inside package."
echo "Plugin source: $SRC_DIR"

# ---- 2. Upgrade only this MediaServer install ------------------------------
# pluginBackUp keeps only the most recent run's snapshot. Wipe before each upgrade.
rm -rf "$BACKUP_ROOT"
mkdir -p "$BACKUP_ROOT"
# Prefer the install dir handed to us by the launcher; only fall back to the SCRIPT_DIR/..
# guess (workspace and plugin co-located) when no arg was passed (older mediaserver).
if [ -n "$PLUGIN_DIR_ARG" ]; then
    plugin_dir="$PLUGIN_DIR_ARG"
else
    plugin_dir="$BASE_PATH/plugins/$PLUGIN_NAME"
fi

if [ ! -d "$plugin_dir" ]; then
    fail "No $PLUGIN_NAME under $plugin_dir, nothing to upgrade."
fi

echo "----------------------------------------------"
echo "base=$BASE_PATH"
echo "plugin=$plugin_dir"

# 2.0 sweep leftovers from previous upgrades. These are *.old.<oldTS> files left after
# mediaserver got respawned; not referenced anymore so safe to remove.
cleaned=0
for f in "$plugin_dir"/*.old.*; do
    [ -e "$f" ] || continue
    rm -f "$f" && cleaned=$((cleaned + 1))
done
[ "$cleaned" -gt 0 ] && echo "cleaned $cleaned stale *.old.* file(s)"

# 2.1 backup. cp is safe even though the .so is mmap'd by mediaserver.
bak="$BACKUP_ROOT/$TS"
mkdir -p "$bak"
if ! cp -a "$plugin_dir" "$bak/"; then
    fail "backup failed"
fi
echo "backup -> $bak"

# 2.2 rename existing files (releases the directory entries so new files can take their
# place). The currently-loaded .so keeps its inode and stays mapped in mediaserver.
for f in "$plugin_dir"/*; do
    [ -e "$f" ] || continue
    if ! mv -f "$f" "${f}.old.${TS}"; then
        fail "rename failed: $f"
    fi
done

# 2.3 drop in the new files
if ! cp -rf "$SRC_DIR"/* "$plugin_dir/"; then
    echo "copy new plugin failed; rolling back from $bak"
    find "$plugin_dir" -mindepth 1 -maxdepth 1 ! -name "*.old.${TS}" -exec rm -rf {} +
    for f in "$plugin_dir"/*.old."${TS}"; do
        [ -e "$f" ] || continue
        orig="${f%.old.${TS}}"
        mv -f "$f" "$orig"
    done
    fail "copy new plugin failed"
fi
# chmod only the freshly-copied files (we own them). Don't touch the .old.<TS> leftovers
# or the plugin directory itself -- those are still owned by root and chmod would EPERM.
find "$plugin_dir" -mindepth 1 -maxdepth 1 ! -name "*.old.${TS}" -exec chmod 755 {} + 2>/dev/null || true
echo "plugin replaced"

# ---- 2.4 sync NX plugin backup --------------------------------------------
# NX keeps its own plugin backup under /opt/networkoptix/plugins, separate from this
# mediaserver's bin/plugins. Only update it if it already exists -- best-effort, a failure
# here must NOT fail the upgrade (the live plugin is already replaced above). The install
# script chmod'd this dir 777 so the non-root mediaserver user can write it.
NX_BACKUP_PLUGIN_DIR="/opt/networkoptix/plugins/$PLUGIN_NAME"
if [ -d "$NX_BACKUP_PLUGIN_DIR" ]; then
    echo "syncing NX plugin backup -> $NX_BACKUP_PLUGIN_DIR"
    # rm is safe even for an mmap'd .so: unlink drops the dir entry, the inode lives on.
    if rm -rf "$NX_BACKUP_PLUGIN_DIR"/* && cp -rf "$SRC_DIR"/* "$NX_BACKUP_PLUGIN_DIR/"; then
        chmod -R 755 "$NX_BACKUP_PLUGIN_DIR"/* 2>/dev/null || true
        echo "NX plugin backup updated"
    else
        echo "[WARN] failed to update NX plugin backup at $NX_BACKUP_PLUGIN_DIR (continuing)"
    fi
fi

# ---- 3. Cleanup + final status --------------------------------------------
rm -rf "$EXTRACT_DIR"

write_log "complish" ""
echo "=============================================="
echo "Upgrade finished successfully -- mediaserver will restart shortly."
echo "=============================================="
exit 0
