#!/bin/bash

############################################
# This script is for post install of NxOS
# It will download & run update-nxos.sh
WebAddress="asharrem.github.io"
WebHostFiles="https://$WebAddress"
file_name="update-nxos.sh"
Working_Dir="$HOME/Downloads"
TITLE="NxOS Installation Wizard"
############################################

#
# check for internet connectivity while displaying progress bar (uses Whiptail)
# Return IPv4_connected 1 false || 0 true - follows exit status sytax (>0 is error)
# uses PING method and supports FQDN (recommended to confirm DNS working)
#
function check_internet () {
    local counter=0
    local IPv4_connected=1
    local check_address=$1
    local fallback_address="google.com"
    if [[ -z "$check_address" ]]; then check_address=$fallback_address; fi
    while [ $IPv4_connected != 0 ]
    do
        while [ $counter -le 100 ]
        do
            if ping -q -c 1 -W 1 $check_address >/dev/null; then
                # prepare to exit loop
                counter=100
                IPv4_connected=0
            fi 
            # Display Progress Bar - This method supports CTRL + C
            export TERM=linux
            echo $counter | whiptail --gauge "\n Checking Internet connectivity to: $check_address" 8 68 0
            (( counter += 5 ))
            sleep 0.5
        done
        # Display Retry on "No Internet"
        if [ $IPv4_connected != 0 ]; then
            if whiptail --yesno "\n No Route to the Internet! Do you want to retry?" 8 68; then
                counter=0
            else
                break
            fi
        fi
    done
    return $IPv4_connected
}

# wait a little in case network is not ready
if ! check_internet $WebAddress; then
  TERM=ansi whiptail --title "$TITLE" --infobox "\n $WebAddress not ready!!!" 8 68
  sleep 3
  exit 1
fi

# change working directory
TERM=ansi whiptail --title "$TITLE" --infobox "\n Changing Working Dir to $Working_Dir..." 8 68
sleep 0.5
cd "$Working_Dir" || exit

# Download NxOS Updater Script
TERM=ansi whiptail --title "$TITLE" --infobox "\n Downloading $file_name..." 8 68
sleep 0.5
# only download & overwrite newer file - quietly
if ! wget -N -q --show-progress "$WebHostFiles/$file_name"; then
    # Download failed
    TERM=ansi whiptail --title "$TITLE" --infobox "\n Downloading $file_name failed!" 8 68
    sleep 3
    exit 1
fi

# Script must have downloaded so let's run it
# chmod +x $file_name
# shellcheck source=/dev/null
. "$file_name"

# remove new_install flag
if [[ -f /opt/nxos/new_install ]]; then
  TERM=ansi whiptail --title "$TITLE" --infobox "\n Removing new_install flag from /opt/nxos..." 8 68
  sudo rm /opt/nxos/new_install
fi
TERM=ansi whiptail --title "$TITLE" --infobox "\n Finished!!!" 8 68
sleep 3
